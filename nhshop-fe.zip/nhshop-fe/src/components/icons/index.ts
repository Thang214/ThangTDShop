import UserIcon from '@/assets/icons/1.svg'
import SearchIcon from '@/assets/icons/2.svg'
import WishlistIcon from '@/assets/icons/3.svg'
import CartIcon from '@/assets/icons/3.svg'
import Logo from '@/assets/logo.svg'
export { UserIcon, SearchIcon, WishlistIcon, CartIcon, Logo }
