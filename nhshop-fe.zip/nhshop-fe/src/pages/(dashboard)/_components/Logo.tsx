const Logo = () => {
    return (
        <div>
            <img height={130} width={130} alt="logo" src="/logo.svg" />
        </div>
    );
};

export default Logo;
