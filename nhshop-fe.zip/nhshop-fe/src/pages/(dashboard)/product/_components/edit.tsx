import React from "react";

const ProductEditPage = () => {
    return <div style={{ border: "2px solid green" }}>ProductEditPage</div>;
};

export default ProductEditPage;
