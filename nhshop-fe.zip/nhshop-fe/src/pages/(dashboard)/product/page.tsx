import React from "react";
import ProductList from "./_components/list";

const ProductManagement = () => {
    return (
        <>
            <ProductList />
        </>
    );
};

export default ProductManagement;
